import httplib
conn = httplib.HTTPConnection(r"ishare.iask.sina.com.cn")
conn.putrequest("POST", r"/download.php?fileid=22910203")
conn.putheader("Referer", "http://ishare.iask.sina.com.cn/f/22910203.html")
conn.send("")
conn.endheaders()
f = conn.getresponse()
response = f.read()
print f.getheader("Location")
