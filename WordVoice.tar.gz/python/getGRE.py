from urllib import urlopen
from pyquery import PyQuery as pyq 
import httplib, urllib, time
import re
ree = re.compile(r'/f/\d*')
count = 0
for i in range(0, 5):
	doc = pyq(url=r'http://iask.sina.com.cn/u/1791266237/ish?folderid=118606&page='+str(i))
	lilist = doc('li.heading3')
	for item in lilist:
		dlurl = pyq(item).find('a').attr("href")
		filename = pyq(item).find('a').attr("title")
		if isinstance(dlurl, str): 
			if dlurl.find("http") >= 0:
				count = count + 1
				if count < 87:
					continue
				keystr = ree.search(dlurl).group()
				filename = filename[9:]
				keypos = ree.search(dlurl).span()
				keynum = dlurl[keypos[0]+3:keypos[1]]
				postUrl = "/download.php?fileid="+keynum 
				refererUrl = "http://ishare.iask.sina.com.cn/f/"+keynum+".html"
				conn = httplib.HTTPConnection(r"ishare.iask.sina.com.cn")
				conn.putrequest("POST", postUrl)
				conn.putheader("Referer", refererUrl)
				conn.send("")
				conn.endheaders()
				f = conn.getresponse()
				response = f.read()
				location = f.getheader("Location")
				print location
				print count
				print filename
				urllib.urlretrieve(location, "/home/rock/Downloads/GRE/"+filename)
				time.sleep(1)
				print "done"

				



