import urllib
webfile = urllib.urlopen("http://www.bitren.com").read()
fp = file('rhf.html', 'a+')
fp.write(webfile)
fp.close();
