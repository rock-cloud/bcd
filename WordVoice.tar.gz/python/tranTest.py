import time
import httplib
csvFile = open("GRE.csv", 'r')
badFile = open("bad.csv", 'w')
while True:
	rline = csvFile.readline()
	if rline == '':
		break
	word = rline.split("\",\"")[0]
	print word 
	httpServ = httplib.HTTPConnection("translate.google.cn", 80)
	httpServ.connect()
	requestStr = "/translate_tts?ie=UTF-8&q="+word+"&tl=en&total=1&idx=0&textlen="+str(len(word))+"&prev=input"
	httpServ.request('GET', requestStr)
#	httpServ.putheader("User-Agent", r"Mozilla/5.0 (MSIE 9.0; Windows NT 6.1; Trident/5.0)");
	response = httpServ.getresponse()
	print response.status
	if response.status == httplib.OK:
		print "OK!"
		fileStr = response.read()
		file = open("voice/"+word+".mp3", 'w')
		file.write(fileStr)
		time.sleep(0.1)
	else:
		if response.status == 302:
			print response.getheader("Location")
		exit()
	httpServ.close()
badFile.close()
